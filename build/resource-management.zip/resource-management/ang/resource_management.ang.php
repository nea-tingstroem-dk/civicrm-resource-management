<?php
// This file declares an Angular module which can be autoloaded
// in CiviCRM. See also:
// \https://docs.civicrm.org/dev/en/latest/hooks/hook_civicrm_angularModules/n
return [
  'js' => [
    'ang/resource_management.js',
    'ang/resource_management/*.js',
    'ang/resource_management/*/*.js',
  ],
  'css' => [
    'ang/resource_management.css',
  ],
  'partials' => [
    'ang/resource_management',
  ],
  'requires' => [
    'crmUi',
    'crmUtil',
    'ngRoute',
  ],
  'settings' => [],
];
