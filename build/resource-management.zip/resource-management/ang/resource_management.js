(function(angular, $, _) {
  // Declare a list of dependencies.
  angular.module('resource_management', CRM.angRequires('resource_management'));
})(angular, CRM.$, CRM._);
