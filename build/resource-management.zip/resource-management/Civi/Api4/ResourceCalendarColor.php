<?php
namespace Civi\Api4;

/**
 * ResourceCalendarColor entity.
 *
 * Provided by the Resource Management extension.
 *
 * @package Civi\Api4
 */
class ResourceCalendarColor extends Generic\DAOEntity {

}
