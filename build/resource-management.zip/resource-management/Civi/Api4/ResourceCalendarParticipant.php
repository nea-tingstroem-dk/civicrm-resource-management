<?php
namespace Civi\Api4;

/**
 * ResourceCalendarParticipant entity.
 *
 * Provided by the FIXME extension.
 *
 * @package Civi\Api4
 */
class ResourceCalendarParticipant extends Generic\DAOEntity {

}
