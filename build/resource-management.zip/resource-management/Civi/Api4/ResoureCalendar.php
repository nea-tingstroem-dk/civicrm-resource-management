<?php
namespace Civi\Api4;

/**
 * ResoureCalendar entity.
 *
 * Provided by the FIXME extension.
 *
 * @package Civi\Api4
 */
class ResoureCalendar extends Generic\DAOEntity {

}
