<?php
namespace Civi\Api4;

/**
 * ResoureCalendarParticipant entity.
 *
 * Provided by the FIXME extension.
 *
 * @package Civi\Api4
 */
class ResoureCalendarParticipant extends Generic\DAOEntity {

}
