<?php
namespace Civi\Api4;

/**
 * ResourceCalendarSettings entity.
 *
 * Provided by the Resource Management extension.
 *
 * @package Civi\Api4
 */
class ResourceCalendarSettings extends Generic\DAOEntity {

}
