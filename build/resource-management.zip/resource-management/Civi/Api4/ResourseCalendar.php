<?php
namespace Civi\Api4;

/**
 * ResourseCalendar entity.
 *
 * Provided by the FIXME extension.
 *
 * @package Civi\Api4
 */
class ResourseCalendar extends Generic\DAOEntity {

}
