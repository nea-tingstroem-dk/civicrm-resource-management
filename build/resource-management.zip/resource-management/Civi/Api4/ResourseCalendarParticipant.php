<?php
namespace Civi\Api4;

/**
 * ResourseCalendarParticipant entity.
 *
 * Provided by the FIXME extension.
 *
 * @package Civi\Api4
 */
class ResourseCalendarParticipant extends Generic\DAOEntity {

}
