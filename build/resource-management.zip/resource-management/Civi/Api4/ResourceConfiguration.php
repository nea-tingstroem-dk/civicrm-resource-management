<?php
namespace Civi\Api4;

/**
 * ResourceConfiguration entity.
 *
 * Provided by the FIXME extension.
 *
 * @package Civi\Api4
 */
class ResourceConfiguration extends Generic\DAOEntity {

}
