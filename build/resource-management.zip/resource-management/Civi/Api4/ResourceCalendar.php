<?php
namespace Civi\Api4;

/**
 * ResourceCalendar entity.
 *
 * Provided by the FIXME extension.
 *
 * @package Civi\Api4
 */
class ResourceCalendar extends Generic\DAOEntity {

}
